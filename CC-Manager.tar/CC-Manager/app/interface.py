banner_string = """
####################################
#                                  #
#            .--------.            #
#           / .------. \           #
#          / /        \ \          #
#          | |        | |          #
#      ____| |________| |____      #
#    .'    |_|        |_|    '.    #
#    '._______ ______________.'    #
#    |     .'__________'.     |    #
#    '.__.'.'          '.'.__.'    #
#    '.__  | CC-Manager |  __.'    #
#    |   '.'.__________.'.'   |    #
#    '.____'.__________.'____.'    #
#    '.______________________.'    #
#                                  #
####################################
"""

login_menu_string = """
What do you want to do?
1. Register a new account
2. Login
3. Recover password
0. Exit
"""

manager_menu_string = """
What do you want to do?
1. Store a new password
2. List my passwords
3. List passwords shared with me
4. Share one of my passwords
5. Use a sharing token
6. Logout
0. Exit
"""
